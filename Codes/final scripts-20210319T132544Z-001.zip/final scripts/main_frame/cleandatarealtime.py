import serial
import pandas as pd
import matplotlib.pyplot as plt
import EMGfunctions as emgf
import time as Time


#read data from serial port

def Average(emg_filtered):
    return sum(emg_filtered) / len(emg_filtered)



ser = serial.Serial("COM11",115200)
ser.flushInput()
startTime = Time.time()
buffer = []
timeBuff = []


while True:
    if True:
        ser_bytes = ser.readline()
        print (ser_bytes)
        try:
            decoded_bytes = float(ser_bytes[0:len(ser_bytes)-2].decode("utf-8"))
        except:
            continue
        currentTime = Time.time() - startTime
        roundTime = round(currentTime,2)
        
        buffer.append(decoded_bytes)
        timeBuff.append(roundTime)
        if len(buffer)<30:
            continue
        if len(buffer) > 50:
           buffer.pop(0)
           timeBuff.pop(0)
        print(buffer[-1]) 

        emg = buffer
        time = timeBuff

        emgcorrectmean = emgf.remove_mean(emg,time)
        emg_filtered = emgf.emg_filter(emgcorrectmean, time)
        emg_rectified = emgf.emg_rectify(emg_filtered, time)
        emg_filtered, emg_envelope = emgf.alltogether(time, emg, low_pass=15, sfreq=1000, high_band=20, low_band=450)


        avg = Average(emg_filtered)
        print("Average is ",round(avg,2))
        
        



