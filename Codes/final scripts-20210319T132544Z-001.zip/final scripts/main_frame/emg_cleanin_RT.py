


import serial
import pandas as pd
import matplotlib.pyplot as plt
import EMGfunctions as emgf
import time as Time


#read data from serial port


class EmgCollector(object):
    def __init__(self):
        self.startTime = Time.time()
        self.buffer = []
        self.timeBuff = []
        self.emg_rectified = []
   
    

    def update(self,emgRaw,time):
        
        
        self.buffer.append(emgRaw)
        self.timeBuff.append(time)
        if len(self.buffer)<30:
            return 
        if len(self.buffer) > 50:
           self.buffer.pop(0)
           self.timeBuff.pop(0)
        print(self.buffer[-1]) 
        emg = self.buffer
        time = self.timeBuff
        emgcorrectmean = emgf.remove_mean(emg,time)
        emg_filtered = emgf.emg_filter(emgcorrectmean, time)
        self.emg_rectified = emgf.emg_rectify(emg_filtered, time)
        
        emg_filtered, emg_envelope = emgf.alltogether(time, emg, low_pass=15, sfreq=1000, high_band=20, low_band=450)
        
    def getavg(self):
        if len(self.buffer) < 30:
            return(self.buffer[-1])
        avg = sum(self.emg_rectified)/ len(self.emg_rectified)
        return avg 
        print("Average is ",round(avg,2))




