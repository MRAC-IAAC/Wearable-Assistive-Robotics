from madgwickahrs import MadgwickAHRS 

class imuone:
    def __init__(self):
        self.gx = 0
        self.gy = 0
        self.gz = 0
        self.ax = 0
        self.ay = 0
        self.az = 0
        self.magx = 0
        self.magy = 0 
        self.magz = 0
        self.gxupd = False
        self.gyupd = False
        self.gzupd = False
        self.axupd = False
        self.ayupd = False
        self.azupd = False
        self.magxupd = False
        self.magyupd = False
        self.magzupd = False
        self.MadgwickAHRS = MadgwickAHRS()

    def updatedata(self,dataType,value,debug = False):
        print (dataType)
        if dataType == "gx":  
            self.gx = value
            self.gxupd = True
        elif dataType == "gy":
            self.gy = value
            self.gyupd = True
        elif dataType == "gz":
            self.gz = value
            self.gzupd = True
        elif dataType == "ax":
            print ("got aAx")
            self.ax = value
            self.axupd = True
        elif dataType == "ay":
            self.ay = value
            self.ayupd = True
        elif dataType == "az":
            self.az = value
            self.azupd = True
        elif dataType == "magx":
            self.magx = value
            self.magxupd = True
        elif dataType == "magy":
            self.magy = value
            self.magyupd = True
        elif dataType == "magz":
            self.magz = value
            self.magzupd = True
        else:
            raise Exception("Wrong Data Type: %s"%dataType)
        
        if (self.gxupd == True and self.gyupd == True and self.gzupd == True and self.axupd == True and 
        self.ayupd == True and self.azupd == True and self.magxupd == True and self.magyupd == True and 
        self.magzupd == True) or debug:
        
            gyroscope = [self.gx,self.gy,self.gz]
            accelerometer = [self.ax, self.ay, self.az]
            magnetometer = [self.magx, self.magy, self.magz]
            print ( gyroscope,accelerometer,magnetometer)
            self.MadgwickAHRS.update(gyroscope, accelerometer, magnetometer)
        
            self.gxupd = False
            self.gyupd = False
            self.gzupd = False
            self.axupd = False
            self.ayupd = False
            self.azupd = False
            self.magxupd = False
            self.magyupd = False
            self.magzupd = False
        
    def GetQuat(self):
        return self.MadgwickAHRS.quaternion

if __name__ =="__main__":
    temp  = imuone()
    temp.updatedata('ax',2)
    temp.updatedata('gx',3)
    temp.updatedata('magx',4,True)
    q = temp.GetQuat()
    print (q.__array__())




       
     