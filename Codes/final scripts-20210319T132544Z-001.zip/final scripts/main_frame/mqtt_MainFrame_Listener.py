
import paho.mqtt as mqtt
from paho.mqtt import client 
from time import sleep
import os
import json 
import time
import csv
import traceback as tb
import re
import pandas as pandas
import emg_cleanin_RT as emgCln



global emgCSense
emgCSense = emgCln.EmgCollector()

global imus_robo
global imus_sense

imus_robo={} 
imus_sense={}

for i in range(3):
    key1 = "imu_robo"%(str(i))
    key2 = "imu_sense"%(str(i))
    tempimu = imuone()
    imus_robo.update({key:tempimu})
    imus_sense.update({key:tempimu})



startTime = time.time()
global Data_Dict
Data_Dict = {}
global SensorList
SensorList = ["IMU1","IMU2"]





def EMG_SUB(emgSource,message):
    if emgSource == 'sense':
        lcoEmg = emgCSense
        

    
def IMU_SUB(message):
    if 

def on_message(client, userdata, message):
    #print("message received " ,str(message.payload.decode("utf-8")))
    #print("message topic=",message.topic)
    
    if message.topic =="emg_sense/emg":
        EMG_SUB("sense",message.payload.decode("utf-8"))

    print(re.findall("IMU",message.topic))
    if len(re.findall("IMU",message.topic))>0:
        IMU_SUB(message) 
    



def on_log(client, userdata, level, buf):
    #print("log: ",buf)
    pass
def LoadJson():
    #path = "G:\\My Drive\\team2_software_sysData\\"
    path = "/home/shabelson/Documents/iaacSoftware/ExosceleotnIAAC/python/"
    name = "Mqtt_dets.json"

    fileName = os.path.join(path,name)

    with open(fileName) as json_file: 

        data = json.load(json_file) 
    Data_Dict = dict.fromkeys(data.keys())
    for key in Data_Dict.keys():
        Data_Dict[key] =([],[])
    return data
def GetAllTopics(data,pubsub = "sub"):
    topDict = {}
    print (pubsub)
    topTup =[]
    
    emg_filter = "emg"
    if pubsub =="sub" :  topFilter = "sense"
    
    else: topFilter = "robo"
    print (data["Topics"])
    outDict = {}
    for subTop in  data["Topics"]:
    
        
        key = subTop["name"]
        
        try:
            
            if not key.split("_")[1] == topFilter: continue
            if not key.split("_")[0] in SensorList:continue
        except: 
            continue 
    
        del subTop["name"]
    
        for tp in subTop.keys():
            
            subTop[tp] = key +"/"+ subTop[tp]

            topTup.append((subTop[tp],1))
            outDict.update({subTop[tp]:([0],[0])})
        topDict.update({key:subTop})
    return outDict,topTup



serverDict = LoadJson()
    
Data_Dict,topList = GetAllTopics(serverDict)

client = client.Client("PC_1")

client.connect(serverDict["BrokerIP"])

client.on_log=on_log

client.on_message = on_message



while True:
    client.loop_start()
    client.subscribe(topList)
    client.loop_stop()
